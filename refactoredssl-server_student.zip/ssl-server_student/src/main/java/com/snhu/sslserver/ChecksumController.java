package com.snhu.sslserver;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ChecksumController {

    
    private final String myName = "Connor Iles";
    private final String uniqueData = "CS305";

    @GetMapping(value = "/hash", produces = MediaType.TEXT_HTML_VALUE)
    public String getChecksum() {
        String data = myName + ": " + uniqueData;

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            String checksum = bytesToHex(encodedHash);
            
            return "<!doctype html><html><head><title>Checksum</title></head><body>"
                    + "<h1>Checksum Verification</h1>"
                    + "<p><b>Unique Data String:</b> " + data + "</p>"
                    + "<p><b>Algorithm Cipher:</b> SHA-256</p>"
                    + "<p><b>Checksum Hash Value:</b> " + checksum + "</p>"
                    + "</body></html>";
        } catch (NoSuchAlgorithmException e) {
            return "<html><body>Error: SHA-256 algorithm not found.</body></html>";
        }
    }

    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}